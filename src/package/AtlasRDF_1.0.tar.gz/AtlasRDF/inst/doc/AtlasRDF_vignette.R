### R code from vignette source 'AtlasRDF_vignette.Rnw'

###################################################
### code chunk number 1: AtlasRDF_vignette.Rnw:28-29
###################################################
library("AtlasRDF")


###################################################
### code chunk number 2: AtlasRDF_vignette.Rnw:42-46
###################################################

termhits <- searchForEFOTerms("type II diabetes")

print(termhits)


###################################################
### code chunk number 3: AtlasRDF_vignette.Rnw:55-59
###################################################

efomappings <- getOntologyMappings("<http://purl.bioontology.org/ontology/SNOMEDCT/44054006>")

print(efomappings)


###################################################
### code chunk number 4: AtlasRDF_vignette.Rnw:69-75
###################################################
humanURI <- getTaxonURI("human")

typeIIgenelist <- getSpeciesSpecificEnsemblGenesForExFactor("<http://www.ebi.ac.uk/efo/EFO_0001360>", humanURI)

head(typeIIgenelist)



###################################################
### code chunk number 5: AtlasRDF_vignette.Rnw:88-92
###################################################
#this will take a little while to run
pathways <- getRankedPathwaysForGeneIds(typeIIgenelist[,3])

head(pathways)


###################################################
### code chunk number 6: AtlasRDF_vignette.Rnw:99-100
###################################################
pathways[1]


###################################################
### code chunk number 7: AtlasRDF_vignette.Rnw:109-111
###################################################
genes <- getGenesForPathwayURI(pathways[[1]]@pathwayuri)



###################################################
### code chunk number 8: AtlasRDF_vignette.Rnw:125-127
###################################################
#load("human/human_gene_list.RData") #human_genelist_bg
#load("human/human_factor_counts.RData") #human_factor_counts


###################################################
### code chunk number 9: AtlasRDF_vignette.Rnw:132-134
###################################################
###do enrichment
#transcription_pathway_enrichment <- doFishersEnrichment(genes, human_genelist_bg, human_factor_counts)


###################################################
### code chunk number 10: AtlasRDF_vignette.Rnw:140-141
###################################################
data(transcription_pathway_enrichment)


###################################################
### code chunk number 11: AtlasRDF_vignette.Rnw:146-147
###################################################
vizgraph <- vizPvalues(transcription_pathway_enrichment, "0.00005")


###################################################
### code chunk number 12: AtlasRDF_vignette.Rnw:157-158
###################################################
filteredgenes <- includeOnlySubclasses("efo:EFO_0000408", transcription_pathway_enrichment)


###################################################
### code chunk number 13: AtlasRDF_vignette.Rnw:164-166
###################################################
sortedset <- orderEnrichmentResults(filteredgenes)
vizgraph <- vizPvalues(sortedset[1:20], 0.000001)


